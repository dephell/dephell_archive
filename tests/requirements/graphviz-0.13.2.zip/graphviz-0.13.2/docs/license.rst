.. _license:

License
=======

.. include:: ../LICENSE.txt
